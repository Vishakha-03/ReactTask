import logo from './logo.svg';
import './App.css';
import UserInfo from './components/UserInfo';

function App() {
  return (
    <div className="App">
      <UserInfo/>
    </div>
  );
}

export default App;
