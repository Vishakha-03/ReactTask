import React, { useState, useEffect } from "react";
import { v4 as uuidv4 } from "uuid";
import {
  DeleteOutlined,
  EditOutlined,
  PlusCircleOutlined,
} from "@ant-design/icons";
import {
  Button,
  Col,
  Divider,
  notification,
  Row,
  Table,
  Input,
  Select,
  Tooltip,
  Modal,
  Descriptions,
  Popconfirm,
} from "antd";
import Title from "antd/lib/typography/Title";
const { Option } = Select;

function UserInfo() {
  const [addRecord, setAddRecord] = useState(false);
  const [editRecord, setEditRecord] = useState(false);
  const [selectedRow, setSelectedRow] = useState({});
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [dob, setDOB] = useState("");
  const [married, setMarried] = useState(undefined);
  const [photo, setPhoto] = useState([]);
  const[imgUrl, setImgUrl] = useState([])
  const [tableData, setTableData] = useState([]);

   useEffect(() => {
     if (photo.length < 1) return;
     const newImageURL = [];
     photo.forEach((img) => newImageURL.push(URL.createObjectURL(img)));
     setImgUrl(newImageURL);
   }, [photo]);

  // Validation for all fields
  const checkValidation = () => {
    let _validate = true;
    if (firstName.trim() === "") {
      notification["error"]({
        message: "Invalid First Name",
      });
      _validate = false;
    }
    if (lastName.trim() === "") {
      notification["error"]({
        message: "Invalid Last Name",
      });
      _validate = false;
    }
    if (dob.trim() === "") {
      notification["error"]({
        message: "Invalid DOB",
      });
      _validate = false;
    }
    if (married === undefined) {
      notification["error"]({
        message: "Invalid Marital Status",
      });
      _validate = false;
    }
    if (photo === []) {
      notification["error"]({
        message: "Invalid Image",
      });
      _validate = false;
    }
    return _validate;
  }

  //Adding record on button click
  const handleAddClick = () => {
    let _currentDataSource = Object.assign([], tableData);
    let temp = {
      id: uuidv4(),
      firstName,
      lastName,
      dob,
      married,
      imgUrl,
    };
    _currentDataSource.push(temp);
    setTableData(_currentDataSource);
  };
  // Deleting record from table on delete button click
  const handleDeleteConfirm = (_id) => {
    console.log(_id);
    let _deletedRecord = tableData.filter((item) => item.id !== _id);
    console.log(_deletedRecord);
    setTableData(_deletedRecord);
  };
  //Open the modal on edit button click to update the record
  const handleEditRecord = (record) => {
    console.log(record);
    setSelectedRow(record);
    setEditRecord(true);
  };
  // Open the modal to add new record 
  const addNewRecordModal = () => {
    setAddRecord(true);
  };
  //Record added into table on the modal button click
  const handleOk = () => {
    setAddRecord(false);
    if (checkValidation()) {
      handleAddClick();
      notification["success"]({
        message: "Record Added Successfully.",
      });
    }
    clearData();
  };
  // Record Add model close
  const handleCancel = () => {
    setAddRecord(false);
  };
  // Update the record on click of update button of modal 
  const handleEditOk = () => {
    setEditRecord(false);
    let _updateRecord = tableData.map((item) => {
      let temp = Object.assign({}, item);
      if (temp.id === selectedRow.id) {
        temp.firstName = firstName !== "" ? firstName : selectedRow.firstName;
        temp.lastName = lastName !== "" ? lastName : selectedRow.lastName;
        temp.dob = dob !== "" ? dob : selectedRow.dob;
        temp.married = married === undefined ? selectedRow.married : married;
        
      }
      return temp;
    });
    setTableData(_updateRecord);
    setSelectedRow({});
    clearData();
    notification["success"]({
      message: "Record Updated Successfully.",
    });
  };
  // close update modal 
  const handleEditCancel = () => {
    setEditRecord(false);
  };
  // blank the fields
  const clearData = () => {
    setFirstName("");
    setLastName("");
    setDOB("");
    setMarried(undefined);
    
  };
  function onImageChange(e) {
    setPhoto([...e.target.files]);
  }
  // Rendering edit and delete button with each record 
  function renderActionsButton(text, record) {
    return (
      <Row justify="space-between">
        <Col xs={24}>
          <Tooltip title={"Edit data"}>
            <Button
              shape="round"
              icon={<EditOutlined />}
              onClick={() => handleEditRecord(record)}
              style={{ borderRadius: 5, marginRight: 10 }}
            ></Button>
          </Tooltip>
          <Popconfirm
            title="Are you sure to delete this record?"
            onConfirm={() => handleDeleteConfirm(record.id)}
          >
            <Tooltip title={"Delete Record"}>
              <Button
                shape="round"
                icon={<DeleteOutlined />}
                style={{ borderRadius: 5, marginRight: 10, color: "red" }}
              ></Button>
            </Tooltip>
          </Popconfirm>
        </Col>
      </Row>
    );
  }
  // table heads of table 
  const tableHeads = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
    },
    {
      title: "First Name",
      dataIndex: "firstName",
      key: "firstName",
    },
    {
      title: "Last Name",
      dataIndex: "lastName",
      key: "lastName",
    },
    {
      title: "DOB",
      dataIndex: "dob",
      key: "dob",
    },
    {
      title: "Married",
      dataIndex: "married",
      key: "married",
    },
    {
      title: "Photo",
      dataIndex: "imgUrl",
      key: "imgUrl",
    },
    {
      title: "Actions",
      key: "action",
      render: renderActionsButton,
    },
  ];

  return (
    <div style={{ padding: "1%" }}>
      <Row justify="space-between">
        <Col xs={12} sm={8}>
          <Title level={4} style={{ textTransform: "uppercase" }}>
            User Information
          </Title>
        </Col>

        <Col xs={12} sm={8}>
          <Button
            style={{ hight: 50, width: 200, marginLeft: 90 }}
            onClick={addNewRecordModal}
          >
            Add New Record
            <PlusCircleOutlined />
          </Button>
        </Col>
      </Row>
      <Divider style={{ margin: 0 }}></Divider>
      <div style={{ marginTop: "10px", padding: "10px" }}>
        <Row>
          <Table
            columns={tableHeads}
            dataSource={tableData}
            pagination={true}
            tableLayout={"fixed"}
          ></Table>
        </Row>
      </div>
      <Modal
        title="Add New Record"
        visible={addRecord}
        width={"90%"}
        onOk={handleOk}
        onCancel={handleCancel}
        okText={"Add Record"}
        cancelButtonProps={{ style: { display: "none" } }}
        bodyStyle={{ minWidth: 850, minHeight: 200 }}
      >
        <Descriptions layout="horizontal" bordered>
          <Descriptions.Item label="First Name">
            <Input
              size="large"
              style={{ width: 200 }}
              value={firstName}
              onChange={(event) => {
                setFirstName(event.target.value);
              }}
            ></Input>
          </Descriptions.Item>
          <Descriptions.Item label="Last Name">
            <Input
              size="large"
              style={{ width: 200 }}
              value={lastName}
              onChange={(event) => {
                setLastName(event.target.value);
              }}
            ></Input>
          </Descriptions.Item>
          <Descriptions.Item label="DOB">
            <input
              type="date"
              style={{ width: 200, height: 40 }}
              value={dob}
              onChange={(event) => {
                setDOB(event.target.value);
              }}
            />
          </Descriptions.Item>
          <Descriptions.Item label="Married">
            <Select
              size="large"
              style={{ width: 200 }}
              value={married}
              onChange={(value) => {
                setMarried(value);
              }}
            >
              <Option value={"Yes"}>Yes</Option>
              <Option value={"No"}>No</Option>
            </Select>
          </Descriptions.Item>
          <Descriptions.Item label="Photo">
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={onImageChange}
            />
          </Descriptions.Item>
        </Descriptions>
      </Modal>

      {editRecord && (
        <Modal
          title="Edit Record"
          visible={editRecord}
          width={"90%"}
          onOk={handleEditOk}
          onCancel={handleEditCancel}
          okText={"Update Record"}
          cancelButtonProps={{ style: { display: "none" } }}
          bodyStyle={{ minWidth: 850, minHeight: 200 }}
        >
          <Descriptions layout="horizontal" bordered>
            <Descriptions.Item label="First Name">
              <Input
                size="large"
                style={{ width: 200 }}
                value={firstName !== "" ? firstName : selectedRow.firstName}
                onChange={(event) => {
                  setFirstName(event.target.value);
                }}
              ></Input>
            </Descriptions.Item>
            <Descriptions.Item label="Last Name">
              <Input
                size="large"
                style={{ width: 200 }}
                value={lastName !== "" ? lastName : selectedRow.lastName}
                onChange={(event) => {
                  setLastName(event.target.value);
                }}
              ></Input>
            </Descriptions.Item>
            <Descriptions.Item label="DOB">
              <input
                type="date"
                style={{ width: 200, height: 40 }}
                value={dob !== "" ? dob : selectedRow.dob}
                onChange={(event) => {
                  setDOB(event.target.value);
                }}
              />
            </Descriptions.Item>
            <Descriptions.Item label="Married">
              <Select
                size="large"
                style={{ width: 200 }}
                value={married === undefined ? selectedRow.married : married}
                onChange={(value) => {
                  setMarried(value);
                }}
              >
                <Option value={"Yes"}>Yes</Option>
                <Option value={"No"}>No</Option>
              </Select>
            </Descriptions.Item>
            <Descriptions.Item label="Photo">
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={onImageChange}
              />
            </Descriptions.Item>
          </Descriptions>
        </Modal>
      )}
    </div>
  );
}

export default UserInfo;
